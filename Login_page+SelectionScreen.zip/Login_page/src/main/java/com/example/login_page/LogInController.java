package com.example.login_page;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LogInController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
    protected void onLogin(ActionEvent event) {
        String u = usernameField.getText() == null ? "" : usernameField.getText().trim();
        String p = passwordField.getText() == null ? "" : passwordField.getText();

        if (UserStore.validate(u, p)) {
            try {
                // Load SelectionScreen.fxml
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SelectionScreen.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setTitle("Choose a Game");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
                Alert err = new Alert(Alert.AlertType.ERROR);
                err.setTitle("Error");
                err.setHeaderText("Unable to load selection screen");
                err.setContentText(e.getMessage());
                err.showAndWait();
            }
        } else {
            Alert err = new Alert(Alert.AlertType.ERROR);
            err.setTitle("Login Failed");
            err.setHeaderText(null);
            err.setContentText("Invalid username or password.");
            err.showAndWait();
        }
    }

    @FXML
    protected void onSignup(ActionEvent event) throws java.io.IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Signup.fxml"));
        Scene signupScene = new Scene(loader.load(), 450, 450);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Sign Up");
        stage.setScene(signupScene);
        stage.show();
    }
}
