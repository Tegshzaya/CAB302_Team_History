package com.example.login_page;

public class GuessByLocationController {
    private String currentUsername;
    public void setCurrentUsername() {

    }
}
